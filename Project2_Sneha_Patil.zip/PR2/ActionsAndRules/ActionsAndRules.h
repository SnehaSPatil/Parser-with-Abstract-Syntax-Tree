#ifndef ACTIONSANDRULES_H
#define ACTIONSANDRULES_H
///////////////////////////////////////////////////////////////////////
// ActionsAndRules.h - acts on specfied rules for parsing tokens     //
// ver 1.0                                                           //
// Language:    C++, Visual Studio 2015                              //
// Application: Parser with Abstract Syntax Tree component,          //
//                                CSE687 - Object Oriented Design    //
// Author:      Seha Patil, Syracuse University,                     //
//              spatil01@syr.edu                                     //
///////////////////////////////////////////////////////////////////////
/*
  Module Operations: 
  ==================
  The BegginingOfscopes rule checks for the scopes and the Handlepush action pushes creates the tree node and pushes it into the 
  stack. The rest of the actions pop the element ,classify the node and assigns proper valus to the node.
  Public Interface:
  =================
  Toker t(someFile);              // create tokenizer instance
  lineCount();                    // gives the current line count
  scopeStack()                    // gives the instance of stack
  TreeRoot()                      // gives the root of the tree
  
  Build Process:
  ==============
  Required files
    -  - Parser.h, Parser.cpp, ScopeStack.h, ScopeStack.cpp,
      ActionsAndRules.h, ActionsAndRules.cpp, ConfigureParser.cpp,
      ItokCollection.h, SemiExpression.h, SemiExpression.cpp, tokenizer.h, tokenizer.cpp
  Build commands 
    - devenv Project2.sln /rebuild debug
    
  Maintenance History:
  ====================
  ver 1.0 : 12 Mar 16
 */
//
#include <queue>
#include <string>
#include <sstream>
#include "../Parser/Parser.h"
#include <memory>
#include "../SemiExp/itokcollection.h"
#include "../ScopeStack/ScopeStack.h"
#include "../Tokenizer/Tokenizer.h"
#include "../SemiExp/SemiExp.h"


struct ASTNode
{
	std::string type;
	std::string name;
	size_t startLineCount = 0;
	size_t endLineCount = 0;
	std::string show()
	{
		std::ostringstream temp;
		temp << "(";
		temp << type;
		temp << ", ";
		temp << name;
		temp << ", ";
		temp << startLineCount;
		temp << ", ";
		temp << endLineCount;
		temp << ")";
		return temp.str();
	}
	std::vector<ASTNode*> children_;
	void addChild(ASTNode* t)  // makes new node so has no parent
	{
		children_.push_back(t);
	}
};


///////////////////////////////////////////////////////////////
// Repository instance is used to share resources
// among all actions.

class Repository  // application specific
{
  ScopeStack<ASTNode*> stack;
  Scanner::Toker* p_Toker;
  ASTNode *pRoot;
  void Delete(ASTNode* pItem);
  void initializeRoot();
public:
  Repository(Scanner::Toker* pToker)
  {
    p_Toker = pToker;
	initializeRoot();
  }
   ~Repository()
   {
	 Delete(pRoot);
   }
   ScopeStack<ASTNode*>& scopeStack()
  {
    return stack;
  }
  Scanner::Toker* Toker()
  {
    return p_Toker;
  }
  size_t lineCount()
  {
    return (size_t)(p_Toker->currentLineCount());
  }
  ASTNode* TreeRoot()
  {
	  return pRoot;
  }
};

//Innitialize the root node
inline void Repository::initializeRoot()
{
	ASTNode* elem = new ASTNode;
	elem->type = "Global Namespace";
	elem->name = "Global Namespace";
	elem->startLineCount = 0;
	elem->endLineCount = 0;
	scopeStack().push(elem);
	pRoot = elem;
}

// Free's memmory on heap
inline void Repository::Delete(ASTNode* pItem)
{
	//calls delete iteratively on children
	auto iter = pItem->children_.begin();
	while (iter != pItem->children_.end())
	{
		Delete(*iter);
		auto itertemp = iter + 1;
		delete *iter;
		iter = itertemp;
	}
}


///////////////////////////////////////////////////////////////
// rule to detect beginning of anonymous scope

class BeginningOfScope : public IRule
{
public:
  bool doTest(ITokCollection*& pTc)
  {

    if(pTc->find("{") < pTc->length())
    {
	    doActions(pTc);
      return true;
    }
    return true;
  }
};


///////////////////////////////////////////////////////////////
// action to handle scope stack at beginning of scope

class HandlePush : public IAction
{
	Repository* p_Repos;
	std::string controlsignalName_;
public:
	HandlePush(Repository* pRepos)
	{
		p_Repos = pRepos;
	}
	void doAction(ITokCollection*& pTc)
	{
		ASTNode* elem = new ASTNode;
		elem->type = "unknown";
		elem->name = "anonymous";
		elem->startLineCount = p_Repos->lineCount();
		p_Repos->scopeStack().top()->addChild(elem);
		p_Repos->scopeStack().push(elem);
	}
};

///////////////////////////////////////////////////////////////
// action to handle Initializers

class HandlePushInitializers : public IAction
{
	Repository* p_Repos;
public:
	HandlePushInitializers(Repository* pRepos)
	{
		p_Repos = pRepos;
	}
	
	void doAction(ITokCollection*& pTc)
	{
		ITokCollection& tc = *pTc;
		ASTNode* elem = p_Repos->scopeStack().pop();
	   if (tc[tc.length() - 1] == "{" && tc.find("{") - tc.find("=") == 1 && !(tc.find("(") < tc.find("=")))
		{
			std::string name = (*pTc)[pTc->find("=") - 1];
			elem->type = "Initializer";
			elem->name = name;
			elem->startLineCount = p_Repos->lineCount();
		}
	   p_Repos->scopeStack().push(elem);
	}
};

///////////////////////////////////////////////////////////////
// action to handle Functions

class HandlePushFunction : public IAction
{
  Repository* p_Repos;
  std::string controlsignalName_;
public:
  HandlePushFunction(Repository* pRepos)
  {
    p_Repos = pRepos;
  }
  bool isSpecialKeyWord(const std::string& tok)
  {
	  const static std::string keys[]
		  = { "for", "while", "switch", "if", "catch" };
	  for (int i = 0; i<5; ++i)
		  if (tok == keys[i])
		  {
			  controlsignalName_ = keys[i];
			  return true;
		  }
	  return false;
  }
  void doAction(ITokCollection*& pTc)
  {
    //std::cout << "\n--BeginningOfScope rule";
	  ITokCollection& tc = *pTc;
	  size_t len = tc.find("(");
	  ASTNode* elem = p_Repos->scopeStack().pop();
		  if (tc[tc.length() - 1] == "{" && len < tc.length() && !isSpecialKeyWord(tc[len - 1]))
		  {
			  std::string name = (*pTc)[pTc->find("(") - 1];
			  elem->type = "function";
			  if (tc.find("(")- tc.find("]") == 1)
				  name = "lambda";
			  elem->name = name;
			  elem->startLineCount = p_Repos->lineCount();
		  }
  p_Repos->scopeStack().push(elem);
  }
};

///////////////////////////////////////////////////////////////
// action to handle control flow statements and data structs

class HandlePushControlS : public IAction
{
	Repository* p_Repos;
	std::string controlsignalName_;
public:
	HandlePushControlS(Repository* pRepos)
	{
		p_Repos = pRepos;
	}
	bool isSpecialKeyWord(const std::string& tok)
	{
		const static std::string keys1[]
			= { "for", "while", "switch", "if", "catch" };
		for (int i = 0; i<5; ++i)
			if (tok == keys1[i])
			{
				controlsignalName_ = keys1[i];
				return true;
			}

		return false;
	}
	bool isDataStructOrTry(ITokCollection*& pTc)
	{
		const static std::string keys2[]
			= { "class", "struct", "try", "namespace", "do","else" };
		for (int i = 0; i<6; ++i)
			if (pTc->find(keys2[i]) < pTc->length())
			{
				controlsignalName_ = keys2[i];
				return true;
			}
		return false;
	}
	void doAction(ITokCollection*& pTc)
	{
		ITokCollection& tc = *pTc;
		size_t len = tc.find("(");
		ASTNode* elem = p_Repos->scopeStack().pop();
		//checks for conditional signals
		if (tc[tc.length() - 1] == "{" && len < tc.length() && isSpecialKeyWord(tc[len - 1]))
		{
				elem->type = controlsignalName_;
				elem->name = controlsignalName_;
				elem->startLineCount = p_Repos->lineCount();
		}
		//checks for datastructs and other known scopes
		else if (tc[tc.length() - 1] == "{"  && isDataStructOrTry(pTc))
		{
			std::string name = controlsignalName_;
			elem->type = controlsignalName_;
			if(controlsignalName_ != "try" && controlsignalName_ != "do" && controlsignalName_ != "else")
			name = (*pTc)[pTc->find(controlsignalName_) + 1];
			elem->name = name;			
			elem->startLineCount = p_Repos->lineCount();
		}
		p_Repos->scopeStack().push(elem);
	}
};


///////////////////////////////////////////////////////////////
// rule to detect end of scope

class EndOfScope : public IRule
{
public:
  bool doTest(ITokCollection*& pTc)
  {
    if(pTc->find("}") < pTc->length())
    {
      doActions(pTc);
      return true;
    }
    return true;
  }
};

///////////////////////////////////////////////////////////////
// action to handle scope stack at end of scope

class HandlePop : public IAction
{
  Repository* p_Repos;
public:
  HandlePop(Repository* pRepos)
  {
    p_Repos = pRepos;
  }
  void doAction(ITokCollection*& pTc)
  {
    //EndOfScope pops the element";
    if(p_Repos->scopeStack().size() == 0)
      return;
	ASTNode* elem = p_Repos->scopeStack().pop();
	elem->endLineCount = p_Repos->lineCount();
   }
};



#endif
