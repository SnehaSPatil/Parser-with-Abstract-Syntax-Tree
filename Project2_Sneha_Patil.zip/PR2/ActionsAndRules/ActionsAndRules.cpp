///////////////////////////////////////////////////////////////////////
// ActionsAndRules.h - read words from a std::stream                 //
// ver  1.0                                                          //
// Language:    C++, Visual Studio 2015                              //
// Application: Parser with Abstract Syntax Tree component,          //
//                                CSE687 - Object Oriented Design    //
// Author:      Seha Patil, Syracuse University,                     //
//              spatil01@syr.edu                                     //
///////////////////////////////////////////////////////////////////////

#ifdef TEST_ACTIONSANDRULES

#include <fstream>
#include <iostream>
#include <sstream>
#include "ActionsAndRules.h"
#include "../Tokenizer/Tokenizer.h"
#include "../SemiExp/SemiExp.h"
#include "../ScopeStack/ScopeStack.h"

using namespace Scanner;
int main(int argc, char* argv[])
{
  std::cout << "\n  Testing ActionsAndRules class\n "
            << std::string(30,'=') << std::endl;

  try
  {
	
    Toker toker;
	std::string fileSpec = "../Parser/TreeWalkDemo.txt";

	std::fstream in(fileSpec);
	if (!in.good())
	{
		std::cout << "\n  can't open file " << fileSpec << "\n\n";
		return 1;
	}
	else
	{
		std::cout << "\n  processing file \"" << fileSpec << "\"\n";
	}
	toker.attach(&in);
    SemiExp se(&toker);
    Parser parser(&se);
	Repository* pRepo = new Repository(&toker);
	BeginningOfScope* pBeginningOfScope = new BeginningOfScope();
	HandlePush *pHandlePush = new HandlePush(pRepo);
	pBeginningOfScope->addAction(pHandlePush);

	HandlePushInitializers* pHandlePushInitializers = new HandlePushInitializers(pRepo);
	pBeginningOfScope->addAction(pHandlePushInitializers);
	parser.addRule(pBeginningOfScope);

	EndOfScope* pEndOfScope = new EndOfScope();
	HandlePop* pHandlePop = new HandlePop(pRepo);
	pEndOfScope->addAction(pHandlePop);
	parser.addRule(pEndOfScope);

    while(se.get())
      parser.parse();
	size_t len = pRepo->scopeStack().size();
    for(size_t i=0; i<len; ++i)
    {
      std::cout << "\n  " << pRepo->scopeStack().pop()->show();
     }
    std::cout << "\n\n";
  }
  catch(std::exception& ex)
  {
    std::cout << "\n\n  " << ex.what() << "\n\n";
  }
}
#endif
