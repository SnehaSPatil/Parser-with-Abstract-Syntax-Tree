#ifndef SEMIEXPRESSION_H
#define SEMIEXPRESSION_H
///////////////////////////////////////////////////////////////////////
// SemiExpression.h - collect tokens for analysis                    //
// ver 3.2                                                           //
// Language:    C++, Visual Studio 2015                              //
// Application: Parser component, CSE687 - Object Oriented Design    //
// Author:      Sneha Patil, Syracuse University,                    //
//              spatil01@syr.edu                                     //
///////////////////////////////////////////////////////////////////////
/*
* Package Operations:
* -------------------
* This package provides a public SemiExp class that collects and makes
* available sequences of tokens.  SemiExp uses the services of a Toker
* class to acquire tokens.  Each call to SemiExp::get() returns a sequence
* of tokens that ends in {, }, ;, and '\n' if the line begins with #.
* A special case for returning for loop as a single token upto first open
* brace is also handled.pubApart from that public :, protected :, private :
* are treated as terminators
*
*  Public Interface:
=================
Toker t;                                  // create tokenizer instance
SemiExp se(&t);                           // create instance and attach
if(se.get())                              // collect a semiExpression
std::cout << "\n  " << se.show();         // show it
int n = se.length();                      // number of tokens in se
if(se.find("aTok") < se.length())         // search for a token
std::cout << "found aTok";
trimFront()                               // removes \n from front of the semiExpression
toLower()                                 // changes the characters to lower case
se.clear();                               // remove all tokens

* Build Process:
* --------------
* Required Files:
*   SemiExpression.h, SemiExpression.cpp, Tokenizer.h, Tokenizer.cpp
*
* Build Command: devenv Project2.sln /rebuild debug
*
* Maintenance History:
* --------------------
* ver 1.0 : 9 Feb 2016
* - first release of new design
*/

#include <vector>
#include <string>
#include "../Tokenizer/Tokenizer.h"
#include "../SemiExp/itokcollection.h"

namespace Scanner
{

	class SemiExp :public ITokCollection
	{
	public:
		SemiExp(Toker* pToker = nullptr);
		SemiExp(const SemiExp&) = delete;
		SemiExp& operator=(const SemiExp&) = delete;
		bool get(bool clear = true);
		std::string& operator[](size_t n);
		std::string operator[](size_t n) const;
		size_t length();
		size_t find(const std::string& tok);
		void trimFront();
		void toLower();
		bool remove(const std::string& tok);
		bool remove(size_t n);
		void push_back(const std::string& tok);
		void clear();
		std::string show(bool showNewLines = false);
		size_t currentLineCount();
		bool merge(const std::string& firstTok, const std::string& secondTok)
		{
			return true;
		}
	private:
		bool isComment(const std::string& tok);
		bool getHelper(bool clear);
		bool isForLoop();
		std::vector<std::string> _tokens;
		Toker* _pToker;
	};
}
#endif
