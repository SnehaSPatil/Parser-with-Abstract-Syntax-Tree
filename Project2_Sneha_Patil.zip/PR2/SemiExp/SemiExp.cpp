///////////////////////////////////////////////////////////////////////
// SemiExpression.cpp - collect tokens for analysis                  //
// ver 1.0                                                         //
// Language:    C++, Visual Studio 2015                            //
// Application: Parser with Abstract Syntax Tree component,         //
//                                CSE687 - Object Oriented Design  //
// Author:      Seha Patil, Syracuse University,                   //
//              spatil01@syr.edu                                   //
/////////////////////////////////////////////////////////////////////


#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <unordered_map>
#include <exception>
#include <cctype>
#include "SemiExp.h"
#include "../Tokenizer/Tokenizer.h"

using namespace Scanner;
using Token = std::string;

// initialize semiExpression with existing toker reference

SemiExp::SemiExp(Toker* pToker) : _pToker(pToker) {}

// returns position of tok in semiExpression 

size_t SemiExp::find(const std::string& tok)
{
	size_t i;
	for (i = 0; (i <_tokens.size() && !(_tokens[i] == tok)); i++);
	return i;
}
// push token onto back end of SemiExp 

void SemiExp::push_back(const std::string& tok)
{
  _tokens.push_back(tok);
}
//removes token passed as argument

bool SemiExp::remove(const std::string& tok)
{
	std::vector<Token>::iterator iterator = _tokens.begin();
	size_t i = find(tok);
	if (i < _tokens.size())
	{
		iterator += i;
		_tokens.erase(iterator);
		return true;
	}
	return false;
}
//removes token at nth position of semiExpression 

bool SemiExp::remove(size_t i)
{
	std::vector<Token>::iterator iterator = _tokens.begin();
	if (i < 0 || _tokens.size() <= i)
	{
		return false;
	}
	iterator += i;
	_tokens.erase(iterator);
	return true;
}
// removes newlines from front of semiExpression 

void SemiExp::trimFront()
{
	while (length() > 0 && (_tokens[0] == "\n" || _tokens[0] == " "))
	{
		remove(0);
	}
}
// transform all tokens to lower case 

void SemiExp::toLower()
{
	for (size_t i = 0; i < length(); i++)
	{
		for (size_t j = 0; j < _tokens[i].length(); j++)
		{
			_tokens[i][j] = tolower(_tokens[i][j]);
		}
	}
}

// clear contents of SemiExp 

void SemiExp::clear()
{
  _tokens.clear();
}

// is this token a comment? 

bool SemiExp::isComment(const std::string& tok)
{
	if (tok.find("//") < tok.size() || tok.find("/*") < tok.size())
		return true;
	return false;
}

//return count of newlines retrieved by Toker
size_t SemiExp::currentLineCount()
{
  if (_pToker == nullptr)
    return 0;
  /* 
   *  Tokenizer has collected first non-state char when exiting eatChars()
   *  so we need to subtract 1 from the Toker's line count.
   */
  return _pToker->currentLineCount() - 1;
}

//helps folding for expressions 

bool SemiExp::isForLoop()
{
	//checks if given token is for loop by looking for the order "for" followed by "(" followed by ";"
	size_t l1 = find("(");
	if (l1 < length())
	{
		size_t	l2 = find("for");
		if (l2 < l1)
		{
			return true;
		}
	}
	return false;
}
//----< fills semiExpression collection from attached toker >--------

bool SemiExp::get(bool clear)
{
	bool issuccessful = getHelper(clear);
	if (_tokens.size() == 0)
		return issuccessful;
	if (issuccessful && _tokens[_tokens.size() - 1] == ";")
	{
		if (isForLoop() && !(find("auto") < length()))
		{
			issuccessful = getHelper(false);
			if (issuccessful)
				issuccessful = getHelper(false);
			return issuccessful;
		}
	}
	return issuccessful;
}


// does all the work of collecting tokens for collection 

bool SemiExp::getHelper(bool clear)
{
	if (_pToker == nullptr)
		throw(std::logic_error("no Toker reference"));
	if (clear)
		_tokens.clear();
	while (true)
	{
		std::string token = _pToker->getTok();
		if (token == "")
			break;
		while (isComment(token))
		{
			token = _pToker->getTok();
			if (token == "")
				break;
		}
		_tokens.push_back(token);
		if (token == "{" || token == "}" || token == ";")
			return true;
		if (token == "\n")
		{
			size_t l = find("#");
			if (l < length())
				return true;
		}
		if (length() >= 2)
		{
			if (token == ":" && (_tokens[length() - 2] == "public" || _tokens[length() - 2] == "private" || _tokens[length() - 2] == "protected"))
				return true;
		}
	}
	return false;
}
//----< read only indexing of SemiExpression >-----------------------

Token SemiExp::operator[](size_t n) const
{
  if (n < 0 || n >= _tokens.size())
    throw(std::invalid_argument("index out of range"));
  return _tokens[n];
}
//----< writeable indexing of SemiExpression >-----------------------

Token& SemiExp::operator[](size_t n)
{
  if (n < 0 || n >= _tokens.size())
    throw(std::invalid_argument("index out of range"));
  return _tokens[n];
}
//----< return number of tokens in semiExpression >------------------

size_t SemiExp::length()
{
  return _tokens.size();
}
//----< display collection tokens on console >-----------------------

std::string SemiExp::show(bool showNewLines)
{
	if (length() == 0)
		return "";
	std::string temp;
	for (size_t i = 0; i < _tokens.size(); ++i)
		if (_tokens[i] != "\n" || showNewLines)
		{
			temp.append(" ");
			temp.append(_tokens[i]);
		}
	return temp;
}

#ifdef TEST_SEMIEXP

int main()
{
  std::cout << "\n  Testing SemiExp class";
  std::cout << "\n =======================\n";

  Toker toker;
  //std::string fileSpec = "../Tokenizer/Tokenizer.cpp";
  std::string fileSpec = "../Parser/TreeWalkDemo.txt";

  std::fstream in(fileSpec);
  if (!in.good())
  {
    std::cout << "\n  can't open file " << fileSpec << "\n\n";
    return 1;
  }
  else
  {
    std::cout << "\n  processing file \"" << fileSpec << "\"\n";
  }
  toker.attach(&in);

  SemiExp semi(&toker);
  while(semi.get())
  {
    std::cout << "\n  -- semiExpression -- at line number " << semi.currentLineCount();
    std::cout << semi.show();
  }
  /*
     May have collected tokens, but reached end of stream
     before finding SemiExp terminator.
   */
  if (semi.length() > 0)
  {
    std::cout << "\n  -- semiExpression --";
    semi.show(true);
  }
  std::cout << "\n\n";
  return 0;
}
#endif
