#define METRICSANALYSIS
#ifdef METRICSANALYSIS
///////////////////////////////////////////////////////////////////////
// MetricsAnalysis.h -  Evaluates and displays the size and          // 
// complexity of all functions in each of a set of specified packages//
// ver 1.0                                                           //
// Language:    C++, Visual Studio 2015                              //
// Application: Parser with Abstract Syntax Tree component,          //
//                                CSE687 - Object Oriented Design    //
// Author:      Seha Patil, Syracuse University,                     //
//              spatil01@syr.edu                                     //
///////////////////////////////////////////////////////////////////////
/*
Module Operations:
==================
Evaluates and displays the size and complexity of all functions in each of a set of specified path.
It provides functions to calculate coomplexity , size of functions.

Public Interface:
=================
 AnalyseFunctionComplexity();                 //Finds the Complexity of a function
 DisplayAnalysis();                           //Dislays the analysis results
 buildAST();                                  // Builds the Abstract Syntax tree
 Attach(const std::string& name, bool isFile = true); //Attaches a file 
 printTree();                                   //Prints the tree
 isParserBuilt()                               //cheks if parser was built

Build Process:
==============
Required files
-    Parser.h, Parser.cpp, SemiExpression.h, SemiExpression.cpp,
tokenizer.h, tokenizer.cpp, ItokenCollection.h,AST.h, AST.cpp,
ActionsAndRules.h, ActionsAndRules.cpp, DataStore.h, DataStore.cpp, 
ConfigureParser.h, ConfigureParser.cpp, FileSystem.h, FileSystem.cpp, 
FileMgr.h, FileMgr.cpp, MetricsAnalysis.h,MetricsAnalysis.cpp,
Build commands
- devenv Project2.sln /rebuild debug

Maintenance History:
====================
ver 1.0 : 12 Mar 16
*/
//
#include <vector>
#include <memory>
#include <string>
#include <sstream>
#include "../Parser/ConfigureParser.h"
#include "../Parser/Parser.h"
#include "../ASTree/ast.h"


class AnalysisNode
{
	//The analysis 
	std::string name;
	size_t size = 0;
	size_t complexity = 0;
public:
	void setComplexity(size_t complexity_)
	{
		complexity = complexity_;
	}

	void setSize(size_t size_)
	{
		size = size_;
	}

	void setName(std::string name_)
	{
		name = name_;
	}

	std::string show()
	{
		std::ostringstream temp;
		temp << "(";
		temp << "Function ";
		temp << name;
		temp << ", ";
		temp << "size = ";
		temp << size;
		temp << ", ";
		temp << "complexity = ";
		temp << complexity;
		temp << ")";
		return temp.str();
	}
};

class MetricsAnalysis
{
public:
	MetricsAnalysis() {};
	~MetricsAnalysis() {
		delete pTree_;
	}
	void AnalyseFunctionComplexity();
	void DisplayAnalysis();
	void buildAST();
	bool Attach(const std::string& name, bool isFile = true);
	void printTree();
	bool isParserBuilt()
	{
		bool succeeded = false;
		if (pParser != NULL)
			succeeded = true;
		return succeeded;
	}
private:
	void BuildAnalysisData(ASTNode* pItem_);
	ConfigParseToConsole configure;
	Parser* pParser = NULL;
    ASTNode* pRoot_ = nullptr;
	ASTTree* pTree_ = new ASTTree(pRoot_);
	std::vector<AnalysisNode> collection_;
};

#endif
