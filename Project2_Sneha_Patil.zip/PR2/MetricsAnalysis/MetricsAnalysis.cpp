///////////////////////////////////////////////////////////////////////
// MetricsAnalysis.cpp -  Evaluates and displays the size and        // 
// complexity of all functions in each of a set of specified packages//
// ver 3.3                                                           //
// Language:    C++, Visual Studio 2015                              //
// Application: Parser with Abstract Syntax Tree component,          //
//                                CSE687 - Object Oriented Design    //
// Author:      Seha Patil, Syracuse University,                     //
//              spatil01@syr.edu                                     //
///////////////////////////////////////////////////////////////////////

#include "MetricsAnalysis.h"
#include"../ActionsAndRules/ActionsAndRules.h"

using namespace Scanner;

//Prints the tree
void MetricsAnalysis::printTree()
{
	pTree_->DisplayTree(pRoot_);
}

//Builds the tree
void MetricsAnalysis::buildAST()
{
	if (pParser)
	{
		try
		{
			while (pParser->next())
				pParser->parse();
			std::cout << "\n\n";
		}
		catch (std::exception& ex)
		{
			std::cout << "\n\n    " << ex.what() << "\n\n";
		}
		std::cout << "\n\n";
		//takes the root  from configureParser
		pRoot_ = configure.TreeRoot();
	}
}

//Attaches the file to be analysed
bool MetricsAnalysis::Attach(const std::string& name, bool isFile)
{
	pParser = configure.Build();
	bool isattached = false;
	if (pParser)
	{
		isattached = configure.Attach(name);
	}
	return isattached;
}

//Calculates the complexity

void MetricsAnalysis::AnalyseFunctionComplexity()
{
	BuildAnalysisData(pRoot_);
}

//Helper funstion to analyse complexity data and store in vector
void MetricsAnalysis::BuildAnalysisData(ASTNode* pItem_)
{
	if (pItem_->type == "function")
	{
		AnalysisNode node;
		node.setName(pItem_->name);
		node.setSize(pTree_->CalculateSize(pItem_));
		node.setComplexity(pTree_->CalculateComplexity(pItem_));
		collection_.push_back(node);
	}
	auto iter = pItem_->children_.begin();
	while (iter != pItem_->children_.end())
	{
		BuildAnalysisData(*iter);
		++iter;
	}
}

//Display function to display Analysis
void MetricsAnalysis::DisplayAnalysis()
{
	// analysis data is stored in vector collection
	auto iter = collection_.begin();
	int i = 0;
	while (iter != collection_.end())
	{
		std::cout << "\n";
		std::cout << collection_[i].show();
		std::cout << "\n";
		iter++;
		i++;
	}
}

#ifdef METRICANALYSIS

#include <queue>
#include <string>

int main(int argc, char* argv[])
{
	std::cout << "\n  Testing ASTree module\n "
		<< std::string(32, '=') << std::endl;

	// collecting tokens from files, named on the command line

	if (argc < 2)
	{
		std::cout
			<< "\n  please enter name of file to process on command line\n\n";
		return 1;
	}
	MetricsAnalysis createTree;

	for (int i = 1; i<argc; ++i)
	{
		std::cout << "\n  Processing file " << argv[i];
		std::cout << "\n  " << std::string(16 + strlen(argv[i]), '-');

		if (!createTree.Attach(argv[i]))
		{
			std::cout << "\n  could not open file " << argv[i] << std::endl;
			continue;
		}

		if (!createTree.isParserBuilt())
		{
			std::cout << "\n\n  Parser not built\n\n";
			return 1;
		}

		if (createTree.buildAST())
		{
			createTree.printTree();
			createTree.AnalyseFunctionComplexity();
			createTree.DisplayAnalysis();

		}
	}
}

#endif