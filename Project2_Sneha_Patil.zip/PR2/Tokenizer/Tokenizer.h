#ifndef TOKENIZER_H
#define TOKENIZER_H
///////////////////////////////////////////////////////////////////////
// Tokenizer.h - read words from a std::stream                       //
// ver 3.3                                                           //
// Language:    C++, Visual Studio 2015                              //
// Application: Parser component, CSE687 - Object Oriented Design    //
// Author:      Seha Patil, Syracuse University,                     //
//              spatil01@syr.edu                                     //
///////////////////////////////////////////////////////////////////////
/*
* Package Operations:
* -------------------
* This package provides a public Toker class and private ConsumeState class.
* Toker reads words from a std::stream, throws away whitespace returns words
* from the stream in the order encountered.  Quoted strings, comments and certain
* punctuators and newlines are returned as single tokens. special
* one and two character tokens have defaults that may be changed by calling
* setSpecialSingleChars(string ssc) and setSpecialCharPairs(string scp).
*
* This is a new version, based on the State Design Pattern.  Older versions
* exist, based on an informal state machine design.
*
Public Interface:
=================
Toker t;                        // create tokenizer instance
if(t.attach(someFileName))      // select file for tokenizing
string tok = t.getTok();       // extract first token
setSpecialSingleChars(std::string ssc); //overrides default list of single special characters
setSpecialCharPairs(std::string scp);   //overrides default list of special character pairs
returnComments(bool returnComments);    //Comments are by default on this state can be changed by using returnComments function

* Build Process:
* --------------
* Required Files: Tokenizer.h, Tokenizer.cpp
* Build Command: devenv Project2.sln /rebuild debug
*
* Maintenance History:
* --------------------
* ver 1.0 : 9 Feb 2016
* - first release of new design
*/
#include <iosfwd>
#include <string>

namespace Scanner
{
	class ConsumeState;    // private worker class
	struct Context;        // private shared data storage

	class Toker
	{
	public:
		Toker();
		Toker(const Toker&) = delete;
		~Toker();
		Toker& operator=(const Toker&) = delete;
		bool attach(std::istream* pIn);
		std::string getTok();
		bool canRead();
		void setSpecialSingleChars(std::string ssc);
		void setSpecialCharPairs(std::string scp);
		void returnComments(bool doReturnComments = false);
		size_t currentLineCount();
	private:
		ConsumeState* pConsumer;
		Context* _pContext;
	};
}
#endif
