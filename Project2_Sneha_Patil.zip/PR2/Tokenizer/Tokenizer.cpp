/////////////////////////////////////////////////////////////////////
// Tokenizer.cpp - read words from a std::stream                   //
// ver 1.0                                                         //
// Language:    C++, Visual Studio 2015                            //
// Application: arser with Abstract Syntax Tree component,         //
//                                CSE687 - Object Oriented Design  //
// Author:      Seha Patil, Syracuse University,                   //
//              spatil01@syr.edu                                   //
/////////////////////////////////////////////////////////////////////


#include <iostream>
#include <cctype>
#include <string>
#include <vector>
#include "Tokenizer.h"
#include "..\Utilities\Utilities.h"

namespace Scanner
{
	struct Context
	{
		Context();
		~Context();
		std::string token;
		std::istream* _pIn;
		std::vector<std::string> _sSpecialChar =
		{
			"\n", "<", ">", "{", "}", "[", "]", "(", ")", ":", "=", "+", "-", "*", "."
		};
		std::vector<std::string> _specialCharP =
		{
			"<<", ">>", "::", "++", "--", "==", "+=", "-=", "*=", "/="
		};
		int prevChar;
		int currChar;
		bool _returncomments;
		size_t _lineCount;
		ConsumeState* _pState;
		ConsumeState* _pEatCppComment;
		ConsumeState* _pEatCComment;
		ConsumeState* _pEatWhitespace;
		ConsumeState* _pEatPunctuator;
		ConsumeState* _pEatAlphanum;
		ConsumeState* _pEatSpecialTokens;
		ConsumeState* _pEatQuotedString;
	};

	///////////////////////////////////////////////////////////////////
	// private ConsumeState worker class
	/*
	*   Nota Bene:
	*   - At exit the eatChars() member should return with
	*     currChar set to the first non-state character.
	*   - Each derived class must insure that this condition
	*     is meet.
	*
	*  This ConsumeState class is nearly identical to the
	*  the ConsumeState that uses static member sharing.
	*  We've just replaced the static members with references
	*  to those members stored in the context.
	*/
	class ConsumeState
	{
		friend class Toker;
	public:
		using Token = std::string;
		ConsumeState();
		ConsumeState(const ConsumeState&) = delete;
		ConsumeState& operator=(const ConsumeState&) = delete;
		virtual ~ConsumeState();
		void attach(std::istream* pIn) { _pContext->_pIn = pIn; }
		virtual void eatChars() = 0;
		void consumeChars() {
			_pContext->_pState->eatChars();
			_pContext->_pState = nextState();
		}
		bool canRead() { return _pContext->_pIn->good(); }
		std::string getTok() { return _pContext->token; }
		bool hasTok() { return _pContext->token.size() > 0; }
		ConsumeState* nextState();
		void returnComments(bool doReturnComments = false);
		size_t currentLineCount();
		void setSpecialSingleChars(std::string ssc);
		void setSpecialCharPairs(std::string scp);
		void setContext(Context* pContext);
	protected:
		Context* _pContext;
		int getChar();
		bool checkSpecialSingleChar();
		bool checkSpecialDoubleChar();
		Token makeString(int ch);
	};
}

using namespace Scanner;
using Token = std::string;

//----< used by Toker to provide Consumer with Context ptr >---------

void ConsumeState::setContext(Context* pContext)
{
  _pContext = pContext;
}
//----< replace one and two char tokens >----------------------------

void ConsumeState::setSpecialSingleChars(std::string ssc)
{	
	//Overrides default special single characters
	size_t i;
	_pContext->_sSpecialChar.clear();
		for (i = 0; i < ssc.size(); i+=2)
	{
		if (ssc[i] != ',')
		{
			std::string temp;
			temp += ssc[i];
			_pContext->_sSpecialChar.push_back(temp);
		}
	}
}

void ConsumeState::setSpecialCharPairs(std::string scp)
{
	//Overrides default special character pairs
	size_t i;
	_pContext->_specialCharP.clear();
	for (i = 0; i < scp.size(); i++)
	{
		if (scp[i] != ',')
		{
			std::string temp;
			temp += scp[i];
			i++;
			temp +=(scp[i]);
			_pContext->_specialCharP.push_back(temp);
		}
	}
}
//----< return number of newlines collected from stream >------------

size_t ConsumeState::currentLineCount()
{
	return _pContext->_lineCount; 
}

//----< collect character from stream >------------------------------

int ConsumeState::getChar()
{
    _pContext->prevChar = _pContext->currChar;
    if (_pContext->currChar == '\n')
      ++(_pContext->_lineCount);
	return _pContext->_pIn->get();
}

//----< logs to console if TEST_LOG is defined >---------------------

void testLog(const std::string& msg);  // forward declaration

//----< turn on\off returning comments as tokens >-------------------

void ConsumeState::returnComments(bool doReturnComments)
{
  _pContext->_returncomments = doReturnComments;
}
//----< is tok one of the special one character tokens? >------------

bool ConsumeState::checkSpecialSingleChar()
{
	for (size_t i = 0; i < _pContext->_sSpecialChar.size(); i++)
	{
		if (_pContext->_sSpecialChar[i] == std::string(1, _pContext->currChar))
		{
			return true;
		}
	}
	return false;
}

bool ConsumeState::checkSpecialDoubleChar()
{
	int chNext = _pContext->_pIn->peek();
	if (chNext == EOF)
	{
		_pContext->_pIn->clear();
		// if peek() reads end of file character, EOF, then eofbit is set and
		// _pIn->good() will return false.  clear() restores state to good
		return false;
	}
	std::string chPair;
	chPair = std::string(1, _pContext->currChar);
	chPair.append(1, chNext);
	for (size_t i = 0; i < _pContext->_specialCharP.size(); i++)
	{
		if (_pContext->_specialCharP[i] == chPair)
		{
			return true;
		}
	}
	return false;
}
//----< make a string with this one integer >------------------------

ConsumeState::Token ConsumeState::makeString(int ch)
{
  Token temp;
  return temp += ch;
}
//----< decide which state to use next >-----------------------------

ConsumeState* ConsumeState::nextState()
{
  if (!(_pContext->_pIn->good()))
  {
    return nullptr;
  }
  int chNext = _pContext->_pIn->peek();
  if (chNext == EOF)
  {
    _pContext->_pIn->clear();
    // if peek() reads end of file character, EOF, then eofbit is set and
    // _pIn->good() will return false.  clear() restores state to good
  }
  if (std::isspace(_pContext->currChar) && _pContext->currChar != '\n')
  {
	  return _pContext->_pEatWhitespace;
  }
  if (_pContext->currChar == '/' && chNext == '/')
  {
	  return _pContext->_pEatCppComment;
  }
  if (_pContext->currChar == '/' && chNext == '*')
  {
	  return _pContext->_pEatCComment;
  }
  if (_pContext->currChar == '"' || _pContext->currChar == '\'')
  {
	  return _pContext->_pEatQuotedString;
  }
  if (_pContext->currChar == '\n' || checkSpecialSingleChar() || checkSpecialDoubleChar())
  {
	  //if (_pContext->currChar == '\n')
		 // (_pContext->_lineCount)++;
	  return _pContext->_pEatSpecialTokens;
  }
  if (std::isalnum(_pContext->currChar) || _pContext->currChar == '_')
  {
	  return _pContext->_pEatAlphanum;
  }
  if (ispunct(_pContext->currChar))
  {
	  return _pContext->_pEatPunctuator;
  }
  if (!_pContext->_pIn->good())
	  return _pContext->_pEatWhitespace;
  std::string error = "invalid type, currChar = " + Utilities::Converter<char>::toString(_pContext->currChar);
  throw(std::logic_error(error.c_str()));
}
//----< class that consumes whitespace >-----------------------------

class EatWhitespace : public ConsumeState
{
public:
	EatWhitespace(Context* pContext)
	{
		_pContext = pContext;
	}

	virtual void eatChars()
	{
		testLog("state: eatWhitespace"); //test log is in sync with the token being displayed
		_pContext->token.clear();
		do {
			if (!_pContext->_pIn->good())  // end of stream
				return;
			_pContext->currChar = getChar();
		} while (std::isspace(_pContext->currChar) && _pContext->currChar != '\n');
	}
};

class EatCppComment : public ConsumeState
{
public:
	EatCppComment(Context* pContext)
	{
		_pContext = pContext;
	}
	virtual void eatChars()
	{
		testLog("state: eatCppComment");
		_pContext->token.clear();
		do {
			if (_pContext->_returncomments)
			{
				_pContext->token += _pContext->currChar;
			}
			if (!_pContext->_pIn->good())  // end of stream
				return;
			_pContext->currChar = getChar();
		} while (_pContext->currChar != '\n');
	}
};

class EatCComment : public ConsumeState
{
public:
	EatCComment(Context* pContext)
	{
		_pContext = pContext;
	}
	virtual void eatChars()
	{
		testLog("state: eatCComment");
		_pContext->token.clear();
		do {
			if (_pContext->_returncomments)
			{
				_pContext->token += _pContext->currChar;
			}
			if (!_pContext->_pIn->good())  // end of stream
				return;
			_pContext->currChar = getChar();
		} while (_pContext->prevChar != '*' || _pContext->currChar != '/');
		if (_pContext->_returncomments)
			_pContext->token += _pContext->currChar;
		if (!_pContext->_pIn->good())  // end of stream
			return;
		_pContext->currChar = getChar();
	}
};
class EatQuotedString : public ConsumeState
{
public:
	EatQuotedString(Context* pContext)
	{
		_pContext = pContext;
	}
	virtual void eatChars()
	{
		testLog("state: eatQuotedString");
		int chNext, quotation = _pContext->currChar;
		_pContext->token.clear();
		do {
			chNext = _pContext->_pIn->peek();
			if (_pContext->currChar == '\\' && (chNext == quotation || chNext == '\\'))
			{
				_pContext->token += _pContext->currChar;
				_pContext->currChar = getChar();
				_pContext->token += _pContext->currChar;
				_pContext->currChar = getChar();
			}
			else
			{
				_pContext->token += _pContext->currChar;
				if (!_pContext->_pIn->good())  // end of stream
					return;
				_pContext->currChar = getChar();
			}
		} while (_pContext->currChar != quotation);
		_pContext->token += _pContext->currChar;
		if (!_pContext->_pIn->good())  // end of stream
			return;
		_pContext->currChar = getChar();
	}
};

class EatPunctuator : public ConsumeState
{
public:
	EatPunctuator(Context* pContext)
	{
		_pContext = pContext;
	}
	virtual void eatChars()
	{
		testLog("state: eatPunctuator");
		_pContext->token.clear();
		do {
			_pContext->token += _pContext->currChar;
			if (!_pContext->_pIn->good())  // end of stream
				return;
			_pContext->currChar = getChar();
		} while (ispunct(_pContext->currChar) && !checkSpecialSingleChar()
			&& !checkSpecialDoubleChar() && (_pContext->currChar != '"') && (_pContext->currChar != '\''));
	}
};

class EatAlphanum : public ConsumeState
{
public:
	EatAlphanum(Context* pContext)
	{
		_pContext = pContext;
	}
	virtual void eatChars()
	{
		testLog("state: eatAlphanum");
		_pContext->token.clear();
		do {
			_pContext->token += _pContext->currChar;
			if (!_pContext->_pIn->good())  // end of stream
				return;
			_pContext->currChar = getChar();
		} while (isalnum(_pContext->currChar) || _pContext->currChar == '_');
	}
};

class EatSpecialTokens : public ConsumeState
{
public:
	EatSpecialTokens(Context* pContext)
	{
		_pContext = pContext;
	}
	virtual void eatChars()
	{
		testLog("state: eatSpecialTokens");
		_pContext->token.clear();
		if (checkSpecialDoubleChar())
		{
			_pContext->token += _pContext->currChar;
			_pContext->currChar = getChar();
			_pContext->token += _pContext->currChar;
		}
		else
		{
			_pContext->token += _pContext->currChar;
		}
		if (!_pContext->_pIn->good())  // end of stream
			return;
		_pContext->currChar = getChar();
	}
};
//----< construct shared data storage >------------------------------

Context::Context()
{
  _pEatAlphanum = new EatAlphanum(this);
  _pEatCComment = new EatCComment(this);
  _pEatCppComment = new EatCppComment(this);
  _pEatPunctuator = new EatPunctuator(this);
  _pEatWhitespace = new EatWhitespace(this);
  _pEatSpecialTokens = new EatSpecialTokens(this);
  _pEatQuotedString = new EatQuotedString(this);
   _pState = _pEatWhitespace;
  _lineCount = 1;
  _returncomments = false;
}
//----< return shared resources >------------------------------------

Context::~Context()
{
  delete _pEatAlphanum;
  delete _pEatCComment;
  delete _pEatCppComment;
  delete _pEatPunctuator;
  delete _pEatWhitespace;
  delete _pEatSpecialTokens;
  delete _pEatQuotedString;
}
//----< no longer has anything to do - will be removed >-------------

ConsumeState::ConsumeState() {}

//----< no longer has anything to do - will be removed >-------------

ConsumeState::~ConsumeState() {}

//----< construct toker starting in state EatWhitespace >------------

Toker::Toker()
{
  _pContext = new Context();
  pConsumer = _pContext->_pEatWhitespace;
  pConsumer->setContext(_pContext);
}

//----< destructor deletes the current state >-----------------------
/*
 * deleting any state deletes them all since derived destructor
 * implicitly invokes the base destructor
 */
Toker::~Toker() 
{
  delete _pContext;
  _pContext = nullptr;
}

//----< attach tokenizer to stream >---------------------------------
/*
 * stream can be either a std::fstream or std::stringstream
 */
bool Toker::attach(std::istream* pIn)
{
  if (pIn != nullptr && pIn->good())
  {
    pConsumer->attach(pIn);
    //_pContext->_pIn = pIn;
    return true;
  }
  return false;
}
//----< collect token generated by ConsumeState >--------------------

std::string Toker::getTok()
{
  while(true) 
  {
    if (!pConsumer->canRead())
      return "";
    pConsumer->consumeChars();
    if (pConsumer->hasTok())
      break;
  }
  return pConsumer->getTok();
}
//----< has toker reached the end of its stream? >-------------------

bool Toker::canRead() { return pConsumer->canRead(); }

//----< start/stop returning comments as tokens >--------------------

void Toker::returnComments(bool doReturnComments)
{
  pConsumer->returnComments(doReturnComments);
}

//----< return number of newlines pulled from stream >---------------

size_t Toker::currentLineCount()
{
  return pConsumer->currentLineCount();
}
//----< set one char tokens >--------------------------------

void Toker::setSpecialSingleChars(std::string ssc)
{
	pConsumer->setSpecialSingleChars(ssc);
}

//----< set two char tokens >--------------------------------
void Toker::setSpecialCharPairs(std::string scp)
{
	pConsumer->setSpecialCharPairs(scp);
}

//----< debugging output to console if TEST_LOG is #defined >--------

void testLog(const std::string& msg)
{
#ifdef TEST_LOG
  std::cout << "\n  " << msg;
#endif
}

//----< test stub >--------------------------------------------------

using Helper = Utilities::StringHelper;
using namespace Utilities;

//#define TEST_TOKENIZER
#ifdef TEST_TOKENIZER

#include <fstream>
#include <exception>


int main()
{
  Helper::Title("Testing Tokenizer");

  //std::string fileSpec = "../Tokenizer/Tokenizer.cpp";
  //std::string fileSpec = "../Tokenizer/Tokenizer.h";
  std::string fileSpec = "../Parser/TreeWalkDemo.txt";

  try
  {
    std::ifstream in(fileSpec);
    if (!in.good())
    {
      std::cout << "\n  can't open " << fileSpec << "\n\n";
      return 1;
    }

    {
      Toker toker;
      toker.returnComments();
      toker.attach(&in);
      std::cout << "\n  current line count = " << toker.currentLineCount();
      do
      {
        std::string tok = toker.getTok();
        if (tok == "\n")
          tok = "newline";
        std::cout << "\n -- " << tok;
      } while (in.good());
      std::cout << "\n  current line count = " << toker.currentLineCount();
    }
 
    putline();
    Helper::title("Testing change of special characters");
    std::string newSpecialChars = "., :, +, +=, \n { }";

    Toker toker;
    toker.returnComments();
    toker.setSpecialCharPairs(newSpecialChars);
    in.clear();

    in.seekg(std::ios::beg);
    toker.attach(&in);
    std::cout << "\n  new special tokens: " << newSpecialChars;
    do
    {
      std::string tok = toker.getTok();
      if (tok == "\n")
        tok = "newline";
      std::cout << "\n -- " << tok;
    } while (in.good());
    std::cout << "\n  current line count = " << toker.currentLineCount();
  }
  catch (std::logic_error& ex)
  {
    std::cout << "\n  " << ex.what();
  }
  std::cout << "\n\n";
  return 0;
}
#endif
