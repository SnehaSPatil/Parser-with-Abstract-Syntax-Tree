///////////////////////////////////////////////////////////////////////
// MetricsExcutive.h -  enables collecting metrics for all the       //
//packages with names that match a specified pattern in a directory  //
//tree rooted at a specified path                                    //
// ver 3.3                                                           //
// Language:    C++, Visual Studio 2015                              //
// Application: Parser with Abstract Syntax Tree component,          //
//                                CSE687 - Object Oriented Design    //
// Author:      Seha Patil, Syracuse University,                     //
//              spatil01@syr.edu                                     //
///////////////////////////////////////////////////////////////////////
/*
Module Operations:
==================
This module enables collecting metrics for all the packages with names that match a 
specified pattern in a directory tree rooted at a specified path

Build Process:
==============
Required files
 -    Parser.h, Parser.cpp, SemiExpression.h, SemiExpression.cpp,
      tokenizer.h, tokenizer.cpp, ItokenCollection.h,AST.h, AST.cpp,
      ActionsAndRules.h, ActionsAndRules.cpp, MetricsExecutive.cpp, 
	  DataStore.h, DataStore.cpp, ConfigureParser.h, ConfigureParser.cpp, MetricsAnalysis.cpp,
	  FileSystem.h, FileSystem.cpp, FileMgr.h, FileMgr.cpp, MetricsAnalysis.h,
Build commands 
- devenv Project2.sln

Maintenance History:
====================
ver 1.0 : 12 Mar 16
*/
//
#include <iostream>
#include <queue>
#include <string>
#include "../MetricsAnalysis/MetricsAnalysis.h"
#include "../FileMgr/FileMgr.h"

#define Util StringHelper
class MxExecutive
{
	DataStore ds, dsp;
public:
	DataStore path()
	{
		return dsp;
	}
	void Test1();
	void Test2(int argc, char* argv[]);
};

#define MXECUTIVE
#ifdef MXECUTIVE

int main(int argc, char* argv[])
{
	if (argc < 2)
	{
		std::cout
			<< "\n  please enter name of file to process on command line\n\n";
		return 1;
	}
	MxExecutive Mx;
	Mx.Test1();
	Mx.Test2(argc,argv);
	std::cout << "\n\n\n**Demonstrating requirement 5,6,8,9 Printing the Abstract Syntax Tree and Analysis**";
	std::cout << "\n ===================================================================================\n";
	for (auto path : Mx.path())
	{
		MetricsAnalysis createTree;
		std::cout << "\nRunning Metrics analyser on Fie on path\n  :" << path;
		if (!createTree.Attach(path))
		{
			std::cout << "\n  could not open file " << path << std::endl;
			continue;
		}
		if (!createTree.isParserBuilt())
		{
			std::cout << "\n\n  Parser not built\n\n";
			return 1;
		}
		createTree.buildAST();
		std::cout << "\nDisplaying the Tree\n";
		createTree.printTree();
		std::cout << "\n\nDisplaying the Analysis\n\n";
		createTree.AnalyseFunctionComplexity();
		createTree.DisplayAnalysis();
	}
	std::cout << "\n\n";
	return 0;
}

void MxExecutive::Test1()
{
	std::cout << "\n**Requirements 1, 2, 3, 4, 10 have been demonstrated in the project implementation**\n\n";
	std::cout << "\n ====================================================================================\n";
}

void MxExecutive::Test2(int argc, char* argv[])
{

	std::string path = FileSystem::Path::getFullFileSpec(argv[1]);
	FileMgr fm(argv[1], ds, dsp);
	std::cout << "\n  searching path: " << path << "\n";
	for (int i = 2; i < argc; ++i)
	{
		fm.addPattern(argv[i]);
	}
	fm.search();
	fm.searchPath();
	std::cout << "\n**Demonstrating requirement 7 Printing the files searched on the path**";
	std::cout << "\n ===================================================================\n";
	for (auto fs : ds)
		std::cout << "\n  " << fs;;
}

#endif // MXECUTIVE