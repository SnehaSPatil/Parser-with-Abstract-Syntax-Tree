#ifndef AST_H
#define AST_H
///////////////////////////////////////////////////////////////////////
// AST.h - Supports tree displaying and tree metrics calculations     //
// ver 1.0                                                           //
// Language:    C++, Visual Studio 2015                              //
// Application: Parser with Abstract Syntax Tree component,          //
//                                CSE687 - Object Oriented Design    //
// Author:      Seha Patil, Syracuse University,                     //
//              spatil01@syr.edu                                     //
///////////////////////////////////////////////////////////////////////
/*
Module Operations:
==================
This is a simple class which suports metricsAnalysis in calculation of metrics
Public Interface:
=================
DisplayTree(ASTNode* pItem)            // Displays the tree
size_t CalculateSize(ASTNode* pItem)   // gives the size
CalculateComplexity(ASTNode* pItem)    // gives the complexity of the node

Build Process:
==============
Required files
- ActionsAndRules.h, ActionsAndRules.cpp, AST.h, AST.cpp
Build commands 
- devenv Project2.sln /rebuild debug

Maintenance History:
====================
ver 1.0 : 12 Mar 16
*/
//

#include <vector>
#include <memory>
#include <string>
#include <sstream>
#include "../ActionsAndRules/ActionsAndRules.h"


class ASTTree
{
public:
	
	ASTTree(ASTNode* pRoot);
	void DisplayTree(ASTNode* pItem);
	void setChildCount(size_t childCount)
	{
		childCount_ = childCount;
	}
	// Calculates the size of function
	size_t CalculateSize(ASTNode* pItem)
	{
		std::string temp = pItem->show();
		return	1 + pItem->endLineCount - pItem->startLineCount;
	}
	size_t CalculateComplexity(ASTNode* pItem);
	private:
	size_t childCount_;
	void countChildren(ASTNode* pItem);
	ASTNode* pRoot_ = nullptr;
};

#endif
