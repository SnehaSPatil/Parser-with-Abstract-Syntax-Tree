///////////////////////////////////////////////////////////////////////
// ActionsAndRules.h - acts on specfied rules for parsing tokens     //
// ver 1.0                                                           //
// Language:    C++, Visual Studio 2015                              //
// Application: Parser with Abstract Syntax Tree component,          //
//                                CSE687 - Object Oriented Design    //
// Author:      Seha Patil, Syracuse University,                     //
//              spatil01@syr.edu                                     //
///////////////////////////////////////////////////////////////////////

#include "AST.h"

using namespace Scanner;

ASTTree::ASTTree(ASTNode* pRoot) :pRoot_(pRoot), childCount_(1){};

///////////////////////////////////////////////////////////////
// Itertively Displays the tree

void ASTTree::DisplayTree(ASTNode* pItem)
{
	static size_t indentLevel = 0;
	std::cout << "\n  " << std::string(2 * indentLevel, ' ') << pItem->show();
	auto iter = pItem->children_.begin();
	++indentLevel;
	while (iter != pItem->children_.end())
	{
		DisplayTree(*iter);
		++iter;
	}
	--indentLevel;
}

///////////////////////////////////////////////////////////////
// CalculateComplexity calls private function countChildren
//and returns the complexity of the node

size_t ASTTree::CalculateComplexity(ASTNode* pItem)
{
	childCount_ = 0;
    countChildren(pItem);
	return childCount_;
}

///////////////////////////////////////////////////////////////
// recursive function recCalculateComplexity counts the number of children a node has

void ASTTree::countChildren(ASTNode* pItem)
{
	auto iter = pItem->children_.begin();
	++childCount_;
	while (iter != pItem->children_.end())
	{
		countChildren(*iter);
		++iter;
	}
}
#ifdef TEST_AST

#include <queue>
#include <string>
#include "../ActionsAndRules/ActionsAndRules.h"

int main(int argc, char* argv[])
{
	ScopeStack<ASTNode*> testStack;
	ASTNode* pItem = new ASTNode;

	pItem->type = "function";
	pItem->name = "fun1";
	pItem->startLineCount = 20;
	pItem->endLineCount = 33;
	ASTNode* pItem1 = new ASTNode;
	pItem1->type = "if";
	pItem1->name = "";
	pItem1->startLineCount = 25;
	pItem1->endLineCount = 32;
	pItem->addChild(pItem1);

	ASTNode* pItem2 = new ASTNode;
	pItem2->type = "for";
	pItem2->name = "";
	pItem1->startLineCount = 26;
	pItem1->endLineCount = 30;
	pItem1->addChild(pItem2);

	ASTTree* pTree_ = new ASTTree(pItem);
	pTree_->CalculateComplexity(pItem);
	pTree_->CalculateSize(pItem);
	pTree_->DisplayTree(pItem);
	
}

#endif